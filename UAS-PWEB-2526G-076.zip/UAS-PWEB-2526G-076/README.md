# 📚 Sistem Data Nilai Mahasiswa

## Deskripsi Proyek

Sistem Data Nilai Mahasiswa merupakan aplikasi berbasis web yang dikembangkan menggunakan PHP Native dan MySQL sebagai media penyimpanan data. Aplikasi ini dibuat untuk membantu admin dalam mengelola data nilai mahasiswa secara efektif dan efisien.

Melalui aplikasi ini, pengguna dapat melakukan pengolahan data nilai mahasiswa mulai dari menambahkan data, melihat data, mengubah data, hingga menghapus data. Selain itu, aplikasi juga dilengkapi dengan fitur login sehingga hanya pengguna yang memiliki hak akses yang dapat menggunakan sistem.

---

# Latar Belakang

Pengolahan data nilai mahasiswa yang masih dilakukan secara manual sering kali membutuhkan waktu yang lama dan berpotensi menimbulkan kesalahan pencatatan. Oleh karena itu, dibutuhkan sebuah sistem informasi sederhana yang mampu membantu proses pengelolaan data nilai agar lebih cepat, akurat, dan mudah digunakan.

---

# Tujuan

Tujuan dari pembuatan aplikasi ini adalah:

- Mempermudah pengelolaan data nilai mahasiswa.
- Mengimplementasikan konsep CRUD menggunakan PHP Native.
- Menerapkan penggunaan database MySQL.
- Menerapkan Session Login pada aplikasi web.
- Memenuhi tugas Ujian Akhir Semester Mata Kuliah Pemrograman Web.

---

# Fitur Aplikasi

Aplikasi memiliki beberapa fitur utama, yaitu:

- Login Admin
- Dashboard
- Menampilkan jumlah data mahasiswa
- Menampilkan daftar mahasiswa
- Menambah data mahasiswa
- Mengubah data mahasiswa
- Menghapus data mahasiswa
- Menghitung grade secara otomatis
- Logout

---

# Teknologi yang Digunakan

Bahasa Pemrograman

- PHP Native
- HTML5
- CSS3

Database

- MySQL

Software Pendukung

- XAMPP
- phpMyAdmin
- Visual Studio Code
- Google Chrome

---

# Struktur Folder

```
UAS-PWEB-2526G-076
│
├── css
│   └── style.css
│
├── koneksi.php
├── function.php
├── login.php
├── logout.php
├── index.php
├── daftar.php
├── tambah.php
├── edit.php
├── update.php
├── hapus.php
│
└── README.md
```

---

# Struktur Database

## Database

```
db_nilai
```

## Tabel

```
tb_nilai
```

| Field | Tipe Data | Keterangan |
|--------|-----------|------------|
| id | int | Primary Key |
| nama | varchar(100) | Nama Mahasiswa |
| nim | varchar(20) | NIM |
| mata_kuliah | varchar(100) | Mata Kuliah |
| nilai | int | Nilai |
| grade | varchar(2) | Grade |

---

# Perhitungan Grade

| Nilai | Grade |
|--------|-------|
| 85 - 100 | A |
| 70 - 84 | B |
| 60 - 69 | C |
| 50 - 59 | D |
| < 50 | E |

---

# Cara Menjalankan Program

1. Install XAMPP.
2. Jalankan Apache dan MySQL.
3. Buka phpMyAdmin.
4. Buat database dengan nama:

```
db_nilai
```

5. Buat tabel `tb_nilai`.
6. Letakkan folder project pada:

```
C:\xampp\htdocs\
```

7. Jalankan browser.

```
http://localhost/UAS-PWEB-2526G-076/login.php
```

8. Login menggunakan akun berikut:

Username

```
admin
```

Password

```
admin123
```

---

# Penjelasan Halaman

## Login

Halaman yang digunakan admin untuk masuk ke dalam sistem menggunakan username dan password.

## Dashboard

Menampilkan informasi jumlah data mahasiswa serta menu utama aplikasi.

## Daftar Data

Menampilkan seluruh data mahasiswa dalam bentuk tabel.

## Tambah Data

Digunakan untuk menambahkan data mahasiswa baru.

## Edit Data

Digunakan untuk mengubah data mahasiswa yang telah tersimpan.

## Hapus Data

Digunakan untuk menghapus data mahasiswa dari database.

## Logout

Digunakan untuk keluar dari sistem.

---

# Kelebihan Aplikasi

- Mudah digunakan.
- Tampilan sederhana dan responsif.
- Pengolahan data lebih cepat.
- Data tersimpan pada database MySQL.
- Menggunakan Session Login.
- Perhitungan grade otomatis.

---

# Kekurangan Aplikasi

- Belum terdapat fitur pencarian data.
- Belum tersedia fitur export PDF atau Excel.
- Hak akses masih satu jenis pengguna (Admin).
- Belum mendukung upload foto mahasiswa.

---

# Pengembangan Selanjutnya

Beberapa pengembangan yang dapat dilakukan pada aplikasi ini antara lain:

- Menambahkan fitur pencarian data.
- Menambahkan fitur export PDF.
- Menambahkan fitur export Excel.
- Menambahkan fitur cetak laporan.
- Menambahkan fitur grafik nilai mahasiswa.
- Menambahkan manajemen pengguna (Admin dan Dosen).
- Menggunakan password yang dienkripsi (hash).

---

# Pengembang

**Nama** : Mila Widiya Fitri

**NIM** : 240631100076

**Mata Kuliah** : Pemrograman Web

**Universitas** : Universitas Trunojoyo Madura

**Tahun** : 2026

---

# Lisensi

Proyek ini dibuat untuk keperluan pembelajaran dan penyelesaian tugas Ujian Akhir Semester (UAS) Mata Kuliah Pemrograman Web.